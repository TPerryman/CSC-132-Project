###########################################################################################
# Name: 
# Date: March 31 2017
# Description: 
###########################################################################################


from Tkinter import *
from random import *
from time import *

Health = 3
Win = 0
# the room class
# note that this class is fully implemented with dictionaries as illustrated in the lesson "More on Data Structures"
class Room(object):
	# the constructor
	def __init__(self, name, image):
		# rooms have a name, an image (the name of a file), exits (e.g., south), exit locations
		# (e.g., to the south is room n), items (e.g., table), item descriptions (for each item),
		# and grabbables (things that can be taken into inventory)
		self.name = name
		self.image = image
		self.exits ={}
		self.items = {}
		self.grabbables = []

	# getters and setters for the instance variables
	@property
	def name(self):
		return self._name

	@name.setter
	def name(self, value):
		self._name = value

	@property
	def image(self):
		return self._image

	@image.setter
	def image(self, value):
		self._image = value

	@property
	def exits(self):
		return self._exits

	@exits.setter
	def exits(self, value):
		self._exits = value

	@property
	def items(self):
		return self._items

	@items.setter
	def items(self, value):
		self._items = value

	@property
	def grabbables(self):
		return self._grabbables

	@grabbables.setter
	def grabbables(self, value):
		self._grabbables = value

	# adds an exit to the room
	# the exit is a string (e.g., north)
	# the room is an instance of a room
	def addExit(self, exit, room):
		# append the exit and room to the appropriate dictionary
		self._exits[exit] = room

	# adds an item to the room
	# the item is a string (e.g., table)
	# the desc is a string that describes the item (e.g., it is made of wood)
	def addItem(self, item, desc):
		# append the item and description to the appropriate dictionary
		self._items[item] = desc

	# adds a grabbable item to the room
	# the item is a string (e.g., key)
	def addGrabbable(self, item):
		# append the item to the list
		self._grabbables.append(item)

	# removes a grabbable item from the room
	# the item is a string (e.g., key)
	def delGrabbable(self, item):
		# remove the item from the list
		self._grabbables.remove(item)

	# returns a string description of the room
	def __str__(self):
		# first, the room name
		s = "You are in {}.\n".format(self.name)

		# next, the items in the room
		s += "You see: "
		for item in self.items.keys():
			s += item + " "
		s += "\n"

		# next, the exits from the room
		s += "Exits: "
		for exit in self.exits.keys():
			s += exit + " "

		s += "\nHealth: {}".format(Health)

		return s

# the game class
# inherits from the Frame class of Tkinter
class Game(Frame):
        # the constructor
        def __init__(self, parent):
                # call the constructor in the superclass
                Frame.__init__(self, parent)

        # creates the rooms
        def createRooms(self):
                global r3
                global r2
                global r5
                global b1
                global b2
                r1 = Room("Hall 1", "hall1.gif")
                r2 = Room("Room 1", "room1.gif")
                r3 = Room("Hall 2", "hall3.gif")
                r4 = Room("Room 2", "room2.gif")
                r5 = Room("Hall 3", "hall2.gif")
                r6 = Room("Bathroom", "bathroom.gif")

                b1 = Room("Boss Room 1", "question.gif")
                b2 = Room("Boss Room 2", "question.gif")


                

                r1.addExit("left", r2)
                r1.addExit("right",r3)
                r1.addExit("up", r5)
                r1.addItem("elevator", "Looks like it still runs...")

                r2.addExit("right", r1)
                r2.addItem("couch", "Looks like there was a fight here.")

                r3.addExit("back", r1)
                r3.addExit("left", r4)
                r3.addExit("forward",b1)
                r3.addItem("closed_door", "it looks like it's locked. Maybe there's a key.")

                r4.addExit("right",r3)
                r4.addExit("forward", r6)
                r4.addItem("desk", "It looks like there is nothing in it.")
                r4.addItem("chair","I would sit down, but I don't get tired.")
                r4.addItem("mirror","Looking good.")

                r5.addExit("down",r1)
                r5.addExit("forward", b2)

                r6.addExit("back", r4)
                r6.addGrabbable("key")
                r6.addItem("mirror", "You see your reflection and feel empowered.\nYou know what you must Scooby-Dooby-Do.")

                b1.addExit("back", r3)
                b1.addItem("question", "What is the answer? (Type choose a, b, or c)")

                b2.addExit("back", r5)
                b2.addItem("question", "What is the answer? (Type choose a, b, or c)")

                Game.currentRoom = r1
                Game.inventory = []
                

        # sets up the GUI
        def setupGUI(self):
                self.pack(fill = BOTH, expand = 1)
                Game.player_input = Entry(self, bg = "white")
                Game.player_input.bind("<Return>", self.process)
                Game.player_input.pack(side = BOTTOM, fill = X)
                Game.player_input.focus()

                img = None
                Game.image = Label(self, width = WIDTH / 2, image = img)
                Game.image.image = img
                Game.image.pack(side = LEFT, fill = Y)
                Game.image.pack_propagate(False)

                text_frame = Frame(self, width = WIDTH / 2)
                Game.text = Text(text_frame, bg = "lightgrey", state = DISABLED)
                Game.text.pack(fill = Y, expand = 1)
                text_frame.pack(side = RIGHT, fill = Y)
                text_frame.pack_propagate(False)
                

        # sets the current room image
        def setRoomImage(self):
                if (Health == 0):
                        Game.img = PhotoImage(file = "skull.gif")
                elif (Win >= 1):
                        Game.img = PhotoImage(file = "win.gif")
                else:
                        Game.img= PhotoImage(file = Game.currentRoom.image)

                Game.image.config(image = Game.img)
                Game.image.image = Game.img
                

        # sets the status displayed on the right of the GUI
        # health counter; goes down by one when you lose rock-paper-scissors
        #Your win counter will go up after beating the second boss which is set to take you to the win screen.
        def setStatus(self, status):
                Game.text.config(state = NORMAL)
                Game.text.delete("1.0", END)
                if (Health == 0):
                        Game.text.insert(END, "You are dead. The only thing you can do now is quit.\n")
                elif (Win >= 1):
                        Game.text.insert(END, "You won the game.\nCongratulations!")
                else:
                        Game.text.insert(END, str(Game.currentRoom) + "\nYou are carrying: " + str(Game.inventory) + "\n\n" + status)
                        Game.text.config(state = DISABLED)

        # plays the game
        def play(self):
                # add the rooms to the game
                self.createRooms()
                # configure the GUI
                self.setupGUI()
                # set the current room
                self.setRoomImage()
                # set the current status
                self.setStatus("")



        # processes the player's input
        def process(self, event):
                action = Game.player_input.get()
                action = action.lower()
                response = "I do not understand. Try verb noun. Valid verbs are go, look, take, and play."

                if (action == "quit" or action == "exit" or action == "bye" or action == "sionara!"):
                        exit(0)
                        
                if (Game.currentRoom == None):
                        Game.player_input.delete(0, END)
                        return

                words = action.split()

                # sets verbs player can use
                if (len(words) == 2):
                        verb = words[0]
                        noun = words[1]
                        
                        # a key is required to open Room 3 in Hall 2 and a scooby snack is required to get into Boss Room 2
                        if (verb == "go"):
                                response = "Invalid exit."
                                if (noun in Game.currentRoom.exits):  
                                        Game.currentRoom = Game.currentRoom.exits[noun]
                                        response = "Room changed."

                        elif (verb == "look"):
                                response = "I do not see that item."
                                if (noun in Game.currentRoom.items):
                                    response = Game.currentRoom.items[noun]
                                    
                        elif (verb == "take"):
                                response = "I do not see that item."
                                for grabbable in Game.currentRoom.grabbables:
                                    if (noun == grabbable):
                                            Game.inventory.append(grabbable)
                                            Game.currentRoom.delGrabbable(grabbable)
                                            response = "Item grabbed."
                                            break

                        # Questions               
                        elif (verb == "choose"):  # keeps player from being able to start the game in an undesignated room
                                response = "I cannot do that here"
                                if (Game.currentRoom == b1 or Game.currentRoom == b2):  
                                        if (noun == "a" or noun == "b" or noun == "c"):
                                                if (noun == "a" and Game.currentRoom == b1):
                                                        #This will be a correct answer
                                                        pc = randint(1,3)
                                                        if pc == 1:
                                                                b1.addItem("question2", "What is the answer? (Type choose a, b, or c)")
                                                        elif pc == 2:
                                                                
                                                elif (noun == "c" and Game.cuurentRoom == b2):
                                                        #This will be a correct answer
                                                else:
                                                        
                self.setStatus(response)
                self.setRoomImage()
                Game.player_input.delete(0,END)
                                    
                                    
                                            
                                    

##########################################################
# the default size of the GUI is 800x600
WIDTH = 800
HEIGHT = 600

# create the window
window = Tk()
window.title("Room Adventure")

# create the GUI as a Tkinter canvas inside the window
g = Game(window)
# play the game
g.play()

# wait for the window to close
window.mainloop()
