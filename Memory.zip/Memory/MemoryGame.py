from Tkinter import *
from random import randint

class Game(Frame):
    def __init__(self, parent, num):
        Frame.__init__(self, parent)
        self.p = parent
        self.num = num
        self.d1 = Deck(num)

    def play(self):
        self.createBoard()
        self.createGUI()

    def createBoard(self):
        board = []
        count = 0
        for i in range(self.num):
            board.append([])
            for j in range (self.num):
                board[i].append(self.d1.deck[count].num)
                count += 1

        for i in range(self.num):
            print board[i]

    def createGUI(self):
        self.pack(fill = BOTH, expand = 1)
        Game.player_input = Entry(self, bg = "white")
        Game.player_input.bind("<Return>", self.action)
        Game.player_input.pack(side = BOTTOM, fill = X)
        Game.player_input.focus()

        img = PhotoImage(file = "Blank.gif")
        if self.num == 4:
            side = WIDTH / 4
            
            Game.img1 = Label(self.p, width = side, height = side, image = img)
            Game.img1.pack(side = LEFT)
            Game.img1.pack_propagate(False)
            Game.img1.config(image = img)
            Game.img2 = Label(self.p, width = side, height = side, image = img)
            Game.img2.pack(side = LEFT)
            Game.img2.pack_propagate(False)
            Game.img1.config(image = img)
            Game.img3 = Label(self.p, width = side, height = side, image = img)
            Game.img3.pack(side = LEFT)
            Game.img3.pack_propagate(False)
            Game.img1.config(image = img)
            Game.img4 = Label(self.p, width = side, height = side, image = img)
            Game.img4.pack(side = LEFT)
            Game.img4.pack_propagate(False)
            Game.img1.config(image = img)
            Game.img5 = Label(self.p, width = side, height = side, image = img)
            Game.img5.pack(side = LEFT)
            Game.img5.pack_propagate(False)
            Game.img6 = Label(self.p, width = side, height = side, image = img)
            Game.img6.pack(side = LEFT)
            Game.img6.pack_propagate(False)
            Game.img7 = Label(self.p, width = side, height = side, image = img)
            Game.img7.pack(side = LEFT)
            Game.img7.pack_propagate(False)
            Game.img8 = Label(self.p, width = side, height = side, image = img)
            Game.img8.pack(side = LEFT)
            Game.img8.pack_propagate(False)
            Game.img9 = Label(self.p, width = side, height = side, image = img)
            Game.img9.pack(side = LEFT)
            Game.img9.pack_propagate(False)
            Game.img10 = Label(self.p, width = side, height = side, image = img)
            Game.img10.pack(side = LEFT)
            Game.img10.pack_propagate(False)
            Game.img11 = Label(self.p, width = side, height = side, image = img)
            Game.img11.pack(side = LEFT)
            Game.img11.pack_propagate(False)
            Game.img12 = Label(self.p, width = side, height = side, image = img)
            Game.img12.pack(side = LEFT)
            Game.img12.pack_propagate(False)
            Game.img13 = Label(self.p, width = side, height = side, image = img)
            Game.img13.pack(side = LEFT)
            Game.img13.pack_propagate(False)
            Game.img14 = Label(self.p, width = side, height = side, image = img)
            Game.img14.pack(side = LEFT)
            Game.img14.pack_propagate(False)
            Game.img15 = Label(self.p, width = side, height = side, image = img)
            Game.img15.pack(side = LEFT)
            Game.img15.pack_propagate(False)
            Game.img16 = Label(self.p, width = side, height = side, image = img)
            Game.img16.pack(side = LEFT)
            Game.img16.pack_propagate(False)

    def action(self, event):
        pass
            
        

class Deck (object):
    def __init__(self, x):
        self.deck = []
        if x == 4:
            num = 8
        elif x == 6:
            num = 18
        elif x == 8:
            num = 32
        for i in range(num):
            self.deck.append(Card(i))
            self.deck.append(Card(i))
        self.Shuffle(self.deck)

    def Shuffle(self, deck):
        temp = [""]
        for i in range(len(deck) - 1):
            pos = randint(0, len(deck) - 1)
            temp[0] = deck[i]
            deck[i] = deck[pos]
            deck[pos] = temp[0]

class Card (object):
    def __init__(self, i):
        if i == 1:
           self.img = "A.gif"
           self.num = i
        elif i == 2:
            self.img = "B.gif"
            self.num = i
        elif i == 3:
            self.img = "C.gif"
            self.num = i
        elif i == 4:
            self.img = "D.gif"
            self.num = i
        elif i == 5:
            self.img = "E.gif"
            self.num = i
        elif i == 6:
            self.img = "F.gif"
            self.num = i
        elif i == 7:
            self.img = "G.gif"
            self.num = i
        elif i == 7:
            self.img = "H.gif"
            self.num = i
        elif i == 7:
            self.img = "I.gif"
            self.num = i
        elif i == 7:
            self.img = "J.gif"
            self.num = i
        elif i == 7:
            self.img = "K.gif"
            self.num = i
        elif i == 7:
            self.img = "L.gif"
            self.num = i
        elif i == 7:
            self.img = "M.gif"
            self.num = i
        elif i == 7:
            self.img = "N.gif"
            self.num = i
        elif i == 7:
            self.img = "O.gif"
            self.num = i
        elif i == 7:
            self.img = "P.gif"
            self.num = i
        elif i == 7:
            self.img = "Q.gif"
            self.num = i
        elif i == 7:
            self.img = "R.gif"
            self.num = i
        elif i == 7:
            self.img = "S.gif"
            self.num = i
        elif i == 7:
            self.img = "T.gif"
            self.num = i
        elif i == 7:
            self.img = "U.gif"
            self.num = i
        elif i == 7:
            self.img = "V.gif"
            self.num = i
        elif i == 7:
            self.img = "W.gif"
            self.num = i
        elif i == 7:
            self.img = "X.gif"
            self.num = i
        elif i == 7:
            self.img = "Y.gif"
            self.num = i
        elif i == 7:
            self.img = "Z.gif"
            self.num = i
        elif i == 7:
            self.img = "1.gif"
            self.num = i
        elif i == 7:
            self.img = "2.gif"
            self.num = i
        elif i == 7:
            self.img = "3.gif"
            self.num = i
        elif i == 7:
            self.img = "4.gif"
            self.num = i
        elif i == 7:
            self.img = "5.gif"
            self.num = i
        else:
            self.img = "6.gif"
            self.num = i

    @property
    def img(self):
        return self._img

    @img.setter
    def img(self, image):
        self._img = image

    @property
    def num(self):
        return self._num

    @num.setter
    def num(self, n):
        self._num = n

    def __str__ (self):
        return str(self.num)


###################################################
lvl = 1
WIDTH = 520
HEIGHT = 600

if lvl == 1:
    num = 4
elif lvl == 2:
    num = 6
else:
    num = 8

window = Tk()
window.title("Memory Game")
g = Game(window, num)
g.play()
window.mainloop()











